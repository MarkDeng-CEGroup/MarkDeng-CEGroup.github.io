#include<windows.h>
int main()
{
	system("copy E:\\CEGroup\\����\\ArpSeries\\��ȡ����+\\rccdaemon.lnk C:\\"); 
	while(true)
	{
		if(GetAsyncKeyState(VK_MBUTTON))
		{
			system("taskkill /f /t /im rccdaemon.exe");
		}
		if(GetAsyncKeyState(VK_F2)&&GetAsyncKeyState(VK_F4))
		{
			system("start C:\\rccdaemon.lnk");
		}
	}
}
