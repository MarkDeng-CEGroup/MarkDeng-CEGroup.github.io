#include <iostream>
#include <cstdio>
#include <windows.h>
#define L1 262
#define L2 294
#define L3 330
#define L4 349
#define L5 392
#define L6 440
#define L7 493

#define N1 532
#define N2 588
#define N3 660
#define N4 698
#define N5 784
#define N6 880
#define N7 988

#define H1 1046
#define H2 1175
#define H3 1319
#define H4 1397
#define H5 1568
#define H6 1760
#define H7 1976

#define A 1600
#define B 800
#define C 400
#define D 200
#define E 100
#define F 50
using namespace std;

int main()
{
    while(true)
    {

        if(GetAsyncKeyState('A'))
            Beep(L1,200);
        if(GetAsyncKeyState('S'))
            Beep(L2,200);
        if(GetAsyncKeyState('D'))
            Beep(L3,200);
        if(GetAsyncKeyState('F'))
            Beep(L4,200);
        if(GetAsyncKeyState('G'))
            Beep(L5,200);
        if(GetAsyncKeyState('H'))
            Beep(L6,200);
        if(GetAsyncKeyState('J'))
            Beep(L7,200);

        if(GetAsyncKeyState('1'))
            Beep(H1,200);
        if(GetAsyncKeyState('2'))
            Beep(H2,200);
        if(GetAsyncKeyState('3'))
            Beep(H3,200);
        if(GetAsyncKeyState('4'))
            Beep(H4,200);
        if(GetAsyncKeyState('5'))
            Beep(H5,200);
        if(GetAsyncKeyState('6'))
            Beep(H6,200);
        if(GetAsyncKeyState('7'))
            Beep(H7,200);

        if(GetAsyncKeyState('Q'))
            Beep(N1,200);
        if(GetAsyncKeyState('W'))
            Beep(N2,200);
        if(GetAsyncKeyState('E'))
            Beep(N3,200);
        if(GetAsyncKeyState('R'))
            Beep(N4,200);
        if(GetAsyncKeyState('T'))
            Beep(N5,200);
        if(GetAsyncKeyState('Y'))
            Beep(N6,200);
        if(GetAsyncKeyState('U'))
            Beep(N7,200);
    }
    return 0;
}
