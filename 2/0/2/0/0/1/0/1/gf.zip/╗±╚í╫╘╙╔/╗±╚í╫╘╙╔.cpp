#include<windows.h>
int main()
{
	system("copy E:\\CEGroup\\����\\ArpSeries\\��ȡ����\\Student.lnk C:\\"); 
	while(true)
	{
		if(GetAsyncKeyState(VK_MBUTTON))
		{
			system("taskkill /f /t /im Student.exe");
		}
		if(GetAsyncKeyState(VK_F2)&&GetAsyncKeyState(VK_F4))
		{
			system("start C:\\Student.lnk");
		}
	}
}
